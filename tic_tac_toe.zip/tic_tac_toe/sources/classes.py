class GameState:
    pass

class Turn:
    def __init__(self, r, c):
        self.r, self.c = r, c;
